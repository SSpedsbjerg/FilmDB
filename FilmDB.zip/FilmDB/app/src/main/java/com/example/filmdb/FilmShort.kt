package com.example.filmdb

data class FilmShort(val image: Int, val FilmName: String) {
}